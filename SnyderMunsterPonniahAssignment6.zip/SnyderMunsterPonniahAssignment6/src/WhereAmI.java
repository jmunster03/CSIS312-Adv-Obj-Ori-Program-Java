import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author Snyder, Munster, Ponniah
 */
public class WhereAmI {

    /**
     * @param zc         - Collection of ZipCode objects
     * @param lowIndex   - Low index of current range being searched
     * @param highIndex  - High index of current range being searched
     * @param lookingFor - zip code being searched for
     * @return - returns the reference of the matching ZipCode object
     * @throws Exception - thrown if zip code entered is not in the collection
     */
    public static ZipCode findZip(List<ZipCode> zc, int lowIndex, int highIndex, int lookingFor) throws Exception {

        // If zip code not found, throw exception
        if (lowIndex > highIndex) {
            throw new Exception("No entry found for " + lookingFor);
        }

        // !!!!! NOTE: Every line in the rest of this method must have descriptive
        // comments !!!!!!! Will count off on implementation if not present.

        // your work goes here
        int midIndex = (lowIndex + highIndex) / 2;
        ZipCode midZipCode = zc.get(midIndex);

        // if zip code is found, return and print
        if (midZipCode.zip == lookingFor) {
            return midZipCode;
        }
        //if current position in the tree is less than the index of the zip, call findZip again
        else if (midZipCode.zip < lookingFor) {
            return findZip(zc, midIndex + 1, highIndex, lookingFor);
        }
        // call findZip again if current index is more than index of zip
        else {
            return findZip(zc, lowIndex, midIndex - 1, lookingFor);
        }
    }

    /**
     * @param args the command line arguments
     * @throws IOException
     */
    public static void main(String[] args) throws IOException {
        List<ZipCode> zips = new ArrayList<>();
        String fileName = "src/zipdata.txt";
        List<String> rawData = Files.readAllLines(Paths.get(fileName));

        for (String line : rawData) {
            String[] tmp = line.split(",");
            String city = tmp[0];
            String state = tmp[1];
            int zip = Integer.parseInt(tmp[2]);
            ZipCode zc = new ZipCode(city, state, zip);
            zips.add(zc);
        }

        // This sorts the ZipCode list by zip code so that it is in order
        // when you search it. This allows binary search techniques

        // Sort the zips list here
        zips.sort(null);

        Scanner scan = new Scanner(System.in);
        while (true) {
            System.out.print("Enter Zip Code (0 to end): ");
            int zipToFind = scan.nextInt();

            if (zipToFind > 0) {
                try {
                    // Call findZip to find the zip code
                    ZipCode result = findZip(zips, 0, zips.size() - 1, zipToFind);

                    // When found, print results
                    System.out.println("Found: " + result.zip + " City: " + result.city + " State: " + result.state);
                } catch (Exception e) {
                    System.out.println("Error: " + e.getMessage());
                }
            } else {
                break;
            }
        }
    }
}
