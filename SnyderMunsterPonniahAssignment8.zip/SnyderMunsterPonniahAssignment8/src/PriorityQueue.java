import java.util.LinkedList;

public class PriorityQueue<E> {
    private LinkedList<E> tasks;
    private LinkedList<Integer> priorities;

    //Constructor
    public PriorityQueue(){
        tasks = new LinkedList<>();
        priorities = new LinkedList<>();
    }

    //Adds an item with a priority into the queue
    public void enqueue(E item, int priority) {
        int i = 0;
        // Find the correct position to insert based on priority
        while (i < priorities.size() && priorities.get(i) >= priority) {
            i++;
        }
        tasks.add(i, item); //Insert task at the found position
        priorities.add(i, priority); //Insert priority at the same position
        System.out.println("Queued: " + item + " With Priority " + priority);
    }

    //Removes and returns the highest priority item from the queue
    public E dequeue() {
        if (tasks.isEmpty()) {
            throw new IllegalStateException("Queue is empty");
        }
        //Remove from the head of the list (highest priority)
        priorities.removeLast();
        return tasks.removeLast();
    }

    //Returns the size of the queue
    public int size() {
        return tasks.size();
    }

    //Clears the queue
    public void clear() {
        tasks.clear();
        priorities.clear();
    }
}
