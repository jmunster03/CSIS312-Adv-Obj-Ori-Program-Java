import java.util.Random;

public class TestPriorityQueue {
    public static void main(String[] args) {
        PriorityQueue<String> queue = new PriorityQueue<>();
        Random random = new Random();

        System.out.println("Queueing:");
        //Insert 100 tasks with random priorities
        for (int i = 1; i <= 100; i++) {
            String task = "Task with Priority " + i;
            //Random priority between 0 and 99
            int priority = random.nextInt(100);
            queue.enqueue(task, priority);
        }

        System.out.println("\nDe-Queueing:");
        //Dequeue all tasks and print them
        while (queue.size() > 0) {
            System.out.println(queue.dequeue());
        }
    }
}
