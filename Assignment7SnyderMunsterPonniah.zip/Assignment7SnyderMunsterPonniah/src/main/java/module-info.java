module assignment2.assignment7snydermunsterponniah {
    requires javafx.controls;
    requires javafx.fxml;


    opens assignment2.assignment7snydermunsterponniah to javafx.fxml;
    exports assignment2.assignment7snydermunsterponniah;
}