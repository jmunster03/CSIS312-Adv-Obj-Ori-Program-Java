package addressapp;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import org.w3c.dom.*;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;
import java.util.regex.Pattern;

public class AddressBookController {

    @FXML
    private TextField firstNameField;
    @FXML
    private TextField lastNameField;
    @FXML
    private TextField stateField;
    @FXML
    private TextField zipCodeField;

    private static final String XML_FILE_PATH = "src/addressapp/address_book.xml";

    @FXML
    private void handleClear() {
        firstNameField.clear();  
        lastNameField.clear();
        stateField.clear();
        zipCodeField.clear();
    }

    @FXML
    private void handleFind() {
        try {
            File file = new File(XML_FILE_PATH);
            if (!file.exists()) {
                showAlert("Error", "Address book file not found.");
                return;
            }

            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
            Document doc = docBuilder.parse(file);

            NodeList addresses = doc.getElementsByTagName("address");
            String firstName = firstNameField.getText();
            String lastName = lastNameField.getText();

            boolean found = false;
            for (int i = 0; i < addresses.getLength(); i++) {
                Element address = (Element) addresses.item(i);
                if (address.getElementsByTagName("firstName").item(0).getTextContent().equals(firstName) &&
                    address.getElementsByTagName("lastName").item(0).getTextContent().equals(lastName)) {
                    
                    stateField.setText(address.getElementsByTagName("state").item(0).getTextContent());
                    zipCodeField.setText(address.getElementsByTagName("zipCode").item(0).getTextContent());
                    found = true;
                    break;
                }
            }

            if (!found) {
                showAlert("Not Found", "Address not found.");
            }
        } catch (Exception e) {
            showAlert("Error", "Error finding address: " + e.getMessage());
        }
    }

    @FXML
    private void handleUpdate() {
        if (validateInput()) {
            try {
                File file = new File(XML_FILE_PATH);
                DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
                DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
                Document doc = docBuilder.parse(file);

                NodeList addresses = doc.getElementsByTagName("address");
                String firstName = firstNameField.getText();
                String lastName = lastNameField.getText();

                boolean found = false;
                for (int i = 0; i < addresses.getLength(); i++) {
                    Element address = (Element) addresses.item(i);
                    if (address.getElementsByTagName("firstName").item(0).getTextContent().equals(firstName) &&
                        address.getElementsByTagName("lastName").item(0).getTextContent().equals(lastName)) {

                        // Update the existing entry
                        address.getElementsByTagName("state").item(0).setTextContent(stateField.getText());
                        address.getElementsByTagName("zipCode").item(0).setTextContent(zipCodeField.getText());
                        found = true;
                        break;
                    }
                }

                if (!found) {
                    // Add new entry
                    Element root = doc.getDocumentElement();

                    Element newAddress = doc.createElement("address");

                    Element newFirstName = doc.createElement("firstName");
                    newFirstName.appendChild(doc.createTextNode(firstName));
                    newAddress.appendChild(newFirstName);

                    Element newLastName = doc.createElement("lastName");
                    newLastName.appendChild(doc.createTextNode(lastName));
                    newAddress.appendChild(newLastName);

                    Element newState = doc.createElement("state");
                    newState.appendChild(doc.createTextNode(stateField.getText()));
                    newAddress.appendChild(newState);

                    Element newZipCode = doc.createElement("zipCode");
                    newZipCode.appendChild(doc.createTextNode(zipCodeField.getText()));
                    newAddress.appendChild(newZipCode);

                    root.appendChild(newAddress);
                }

                // Save the updated document
                TransformerFactory transformerFactory = TransformerFactory.newInstance();
                Transformer transformer = transformerFactory.newTransformer();
                DOMSource source = new DOMSource(doc);
                StreamResult result = new StreamResult(file);
                transformer.transform(source, result);

                showAlert("Success", found ? "Address updated successfully." : "New address added successfully.");
            } catch (Exception e) {
                showAlert("Error", "Error updating address: " + e.getMessage());
            }
        }
    }

    @FXML
    private void handleDelete() {
        try {
            File file = new File(XML_FILE_PATH);
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
            Document doc = docBuilder.parse(file);

            NodeList addresses = doc.getElementsByTagName("address");
            String firstName = firstNameField.getText();
            String lastName = lastNameField.getText();

            boolean found = false;
            for (int i = 0; i < addresses.getLength(); i++) {
                Element address = (Element) addresses.item(i);
                if (address.getElementsByTagName("firstName").item(0).getTextContent().equals(firstName) &&
                    address.getElementsByTagName("lastName").item(0).getTextContent().equals(lastName)) {

                    address.getParentNode().removeChild(address);
                    found = true;
                    break;
                }
            }

            if (found) {
                // Save the updated document
                TransformerFactory transformerFactory = TransformerFactory.newInstance();
                Transformer transformer = transformerFactory.newTransformer();
                DOMSource source = new DOMSource(doc);
                StreamResult result = new StreamResult(file);
                transformer.transform(source, result);

                showAlert("Success", "Address deleted successfully.");
                handleClear();
            } else {
                showAlert("Not Found", "Address not found for deletion.");
            }
        } catch (Exception e) {
            showAlert("Error", "Error deleting address: " + e.getMessage());
        }
    }

    private boolean validateInput() {
        String firstName = firstNameField.getText();
        String lastName = lastNameField.getText();
        String state = stateField.getText();
        String zipCode = zipCodeField.getText();

        if (!Pattern.matches("[a-zA-Z]+", firstName) || !Pattern.matches("[a-zA-Z]+", lastName)) {
            showAlert("Validation Error", "First and Last names must be only alphabetic.");
            return false;
        }

        if (!Pattern.matches("[a-zA-Z]{2}", state)) {
            showAlert("Validation Error", "State must be a two-letter alpha abbreviation.");
            return false;
        }

        if (!Pattern.matches("\\d{5}(-\\d{4})?", zipCode)) {
            showAlert("Validation Error", "Zip code must be five digits or five digits plus four.");
            return false;
        }

        return true;
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
