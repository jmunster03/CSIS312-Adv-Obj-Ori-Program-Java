package library;

public class Magazine extends Media implements MediaUtility {
    private double issueCost;
    private int issuesPerYear;

    public Magazine(String title, String publicationDate, double issueCost, int issuesPerYear) {
        super(title, publicationDate);
        this.issueCost = issueCost;
        this.issuesPerYear = issuesPerYear;
    }

    public String print() {
        return "Title: " + getTitle() + ", Published: " + getPublicationDate();
    }

    public double getCost() {
        return issueCost * getIssuesPerYear();
    }

    public int getIssuesPerYear() {
        return issuesPerYear;
    }
}