package library;

interface MediaUtility {
    public abstract String print();
    public abstract double getCost();
}
