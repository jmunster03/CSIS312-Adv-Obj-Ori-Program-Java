package library;

abstract class Media implements MediaUtility, Comparable<Media> {
    private final String title;
    private final String publicationDate;


    public Media(String title, String publicationDate) {
        this.title = title;
        this.publicationDate = publicationDate;
    }

    public String getTitle() {
        return title;
    }

    public String getPublicationDate() {
        return publicationDate;
    }

    public abstract String print();

    @Override
    public int compareTo(Media other) {
        // First, compare by publicationDate
        int dateComparison = this.publicationDate.compareTo(other.publicationDate);
        if (dateComparison != 0) {
            return dateComparison; // If dates are different, return the result
        }
        // If publication dates are the same, compare by title
        return this.title.compareTo(other.title);
    }
}

