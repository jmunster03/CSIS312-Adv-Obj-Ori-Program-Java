package library;


public class Book extends Media{

    private String author;
    private double cost;

    public Book(String title, String publicationDate, String author, double cost){

        super(title, publicationDate);
        this.author = author;
        this.cost = cost;
    }

    public String print() {
        return "Title: " + getTitle() +
                ", Author: " + author +
                ", Publication Date: " + getPublicationDate();
    }

    public String getAuthor(){
        return author;
    }
    public double getCost(){
        return cost;
    }

}
