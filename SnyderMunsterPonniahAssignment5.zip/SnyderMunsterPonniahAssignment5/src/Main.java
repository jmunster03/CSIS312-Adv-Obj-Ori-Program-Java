import java.util.HashMap;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        HashMap<Integer, String> radioCodes = new HashMap<Integer, String>();

        radioCodes.put(1, "Receiving Poorly");
        radioCodes.put(2, "Receiving Well");
        radioCodes.put(3, "Stop transmitting");
        radioCodes.put(4, "Message received");
        radioCodes.put(5, "Relay message");
        radioCodes.put(6, "Busy, standby");
        radioCodes.put(7, "Out of service");
        radioCodes.put(8, "In service");
        radioCodes.put(9, "Repeat Message");
        radioCodes.put(10, "Transmission complete, standing by");
        radioCodes.put(11, "Talking too rapidly");
        radioCodes.put(12, "Visitors present");
        radioCodes.put(13, "Advise weather/road conditions");
        radioCodes.put(16, "Make pick up at ___");
        radioCodes.put(17, "Urgent business");
        radioCodes.put(18, "Anything for us?");
        radioCodes.put(19, "Nothing for you, return to base");
        radioCodes.put(20, "Your current location");
        radioCodes.put(21, "Call by telephone");
        radioCodes.put(22, "Report in person to ___");
        radioCodes.put(23, "Stand by");
        radioCodes.put(24, "Completed last assignment");
        radioCodes.put(25, "Can you contact [name]");
        radioCodes.put(26, "Disregard last info/message");
        radioCodes.put(27, "I'm moving to channel [channel number]");
        radioCodes.put(28, "Identify your station");
        radioCodes.put(29, "Time is up for contact");
        radioCodes.put(30, "Does not conform to FCC rules");
        radioCodes.put(32, "I will give you a radio check");
        radioCodes.put(33, "Emergency traffic at this station");
        radioCodes.put(34, "Trouble at station, help needed");
        radioCodes.put(35, "Confidential Information");
        radioCodes.put(36, "Need correct time");
        radioCodes.put(37, "Wrecker needed at [location]");
        radioCodes.put(38, "Ambulance needed at [location]");
        radioCodes.put(39, "Message delivered");
        radioCodes.put(41, "Tune to channel [number]");
        radioCodes.put(42, "Traffic accident at [location]");
        radioCodes.put(43, "Traffic jam");
        radioCodes.put(44, "I have a message for you");
        radioCodes.put(45, "All units within range please report");
        radioCodes.put(50, "Break channel");
        radioCodes.put(60, "What is next message number?");
        radioCodes.put(62, "Unable to copy, use phone");
        radioCodes.put(65, "Awaiting next message or assignment");
        radioCodes.put(67, "All units comply");
        radioCodes.put(70, "Fire at [location]");
        radioCodes.put(73, "Speed trap");
        radioCodes.put(75, "You are causing interference");
        radioCodes.put(77, "Negative contact");
        radioCodes.put(84, "My telephone number is");
        radioCodes.put(85, "My address is");
        radioCodes.put(91, "Talk closer to the mike");
        radioCodes.put(92, "Your transmitter is out of adjustment");
        radioCodes.put(93, "Check my frequency on this channel");
        radioCodes.put(94, "Give me a long count");
        radioCodes.put(95, "Transmit dead carrier for 5 seconds");
        radioCodes.put(99, "mission complete, all units secure");
        radioCodes.put(100, "Bathroom break");
        radioCodes.put(200, "Police needed at [location]");

        Scanner input = new Scanner(System.in);
        String query = "";

        while (true) {
            System.out.print("Enter code 10- or 'quit' to exit: ");
            query = input.nextLine();

            if (query.equalsIgnoreCase("quit")) {
                break;
            }

            try {
                int code = Integer.parseInt(query);
                if (radioCodes.containsKey(code)) {
                    System.out.println(radioCodes.get(code));
                } else {
                    System.out.println("No meaning for entered code");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid code or 'quit' to exit.");
            }
        }

        input.close();
        System.out.println("Program terminated.");
    }
}